# PINOUT-DOIT ESP32 Devkit V1
DOIT ESP32 DEVKIT V1

Related Article: https://playelek.com/doit-esp32-devkit-v1/

![Image of doit esp32 devkit v1](https://github.com/playelek/pinout-doit-32devkitv1/blob/master/pinoutDOIT32devkitv1.png)

### References
1. DOIT ESP32 DEVKIT V1 schematic https://www.dropbox.com/s/jefwxxtufgwg0ex/esp32_Schematic%20Prints.pdf?dl=0
2. ESP32 Datasheet http://espressif.com/sites/default/files/documentation/esp32_datasheet_en.pdf
3. ESP WROOM32 Datasheet http://espressif.com/sites/default/files/documentation/esp-wroom-32_datasheet_en.pdf
4. wroom32 pinout http://www.pighixxx.com/test/2016/08/wroom32/
